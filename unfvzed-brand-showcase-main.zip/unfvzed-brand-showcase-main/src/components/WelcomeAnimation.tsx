import { useState, useEffect } from "react";

const WelcomeAnimation = () => {
  const [show, setShow] = useState(false);
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    const hasSeenWelcome = sessionStorage.getItem("hasSeenWelcome");
    const hasSeenPopup = sessionStorage.getItem("hasSeenSignupPopup");
    
    if (!hasSeenWelcome) {
      setShow(true);
      const fadeTimer = setTimeout(() => {
        setFadeOut(true);
      }, 2000);
      const hideTimer = setTimeout(() => {
        setShow(false);
        sessionStorage.setItem("hasSeenWelcome", "true");
        
        // Trigger popup after welcome animation if not seen yet
        if (!hasSeenPopup) {
          window.dispatchEvent(new CustomEvent('showSignupDialog'));
        }
      }, 3000);
      return () => {
        clearTimeout(fadeTimer);
        clearTimeout(hideTimer);
      };
    }
  }, []);

  if (!show) return null;

  return (
    <div
      className={`fixed inset-0 z-[100] flex items-center justify-center bg-background transition-opacity duration-1000 px-4 ${
        fadeOut ? "opacity-0" : "opacity-100"
      }`}
    >
      <h1 className="text-4xl md:text-6xl font-extrabold text-black animate-fade-in text-center">
        Welcome to the unfvzed store
      </h1>
    </div>
  );
};

export default WelcomeAnimation;
