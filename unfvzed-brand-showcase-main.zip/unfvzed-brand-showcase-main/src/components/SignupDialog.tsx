import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

const SignupDialog = () => {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const { toast } = useToast();

  useEffect(() => {
    const hasSeenPopup = sessionStorage.getItem("hasSeenSignupPopup");
    const hasSeenWelcome = sessionStorage.getItem("hasSeenWelcome");
    
    // Show immediately if welcome was already seen, otherwise wait for event
    if (!hasSeenPopup && hasSeenWelcome) {
      setOpen(true);
    }
    
    const handleShowDialog = () => {
      if (!sessionStorage.getItem("hasSeenSignupPopup")) {
        setOpen(true);
      }
    };
    
    window.addEventListener('showSignupDialog', handleShowDialog);
    return () => window.removeEventListener('showSignupDialog', handleShowDialog);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && email) {
      sessionStorage.setItem("hasSeenSignupPopup", "true");
      toast({
        title: "Welcome to unfvzed!",
        description: "Check your email for your 10% discount code.",
      });
      setOpen(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-md" onInteractOutside={(e) => e.preventDefault()} data-hide-close="true">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">Get 10% Off Your First Purchase!</DialogTitle>
          <DialogDescription>
            Sign up now and receive an exclusive discount code.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              placeholder="Enter your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <Button type="submit" className="w-full">
            Get My Discount
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default SignupDialog;
