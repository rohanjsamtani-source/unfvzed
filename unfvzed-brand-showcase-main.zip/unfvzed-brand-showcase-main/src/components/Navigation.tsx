import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ShoppingCart } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useCart } from "@/contexts/CartContext";

const Navigation = () => {
  const { getTotalItems } = useCart();
  const cartItemsCount = getTotalItems();

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-6 py-4 flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold tracking-tight">
          unfvzed
        </Link>
        
        <p className="text-sm font-semibold uppercase tracking-wider absolute left-1/2 transform -translate-x-1/2 hidden md:block">
          CRAFTING PREMIUM | SLASHING COSTS
        </p>
        
        <div className="flex items-center gap-3">
          <Link to="/products">
            <Button variant="outline">Products</Button>
          </Link>
          <Link to="/cart">
            <Button variant="outline" className="relative">
              <ShoppingCart className="h-5 w-5" />
              {cartItemsCount > 0 && (
                <Badge className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 text-xs">
                  {cartItemsCount}
                </Badge>
              )}
            </Button>
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
