import acidTeeFront from "@/assets/acid-tee-front.png";
import acidTeeBack from "@/assets/acid-tee-back.jpg";
import bitchdontTeeFront from "@/assets/bitchdont-front-v2.jpg";
import bitchdontTeeBack from "@/assets/bitchdont-back-v2.jpg";

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  images: string[];
  sizes: {
    size: string;
    stock: number;
  }[];
  freeShipping: boolean;
}

// Product catalog
export const products: Product[] = [
  {
    id: "acid-washed-tee",
    name: "Acid Washed Tee",
    description: "240 GSM FRENCH TERRY",
    price: 869,
    images: [
      acidTeeBack,
      acidTeeFront
    ],
    sizes: [
      { size: "S", stock: 30 },
      { size: "M", stock: 30 },
      { size: "L", stock: 30 },
      { size: "XL", stock: 30 },
      { size: "2XL", stock: 30 },
    ],
    freeShipping: true,
  },
  {
    id: "bitchdont",
    name: "BitchDont'",
    description: "220 GSM | STAY BOLD.",
    price: 799,
    images: [
      bitchdontTeeBack,
      bitchdontTeeFront
    ],
    sizes: [
      { size: "S", stock: 30 },
      { size: "M", stock: 30 },
      { size: "L", stock: 30 },
      { size: "XL", stock: 30 },
      { size: "2XL", stock: 30 },
    ],
    freeShipping: true,
  },
];
