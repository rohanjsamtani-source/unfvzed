import Navigation from "@/components/Navigation";
import { products } from "@/data/products";
import { Link } from "react-router-dom";

const Products = () => {
  return (
    <div className="min-h-screen">
      <Navigation />
      <main className="container mx-auto px-6 pt-24 pb-12">
        <h1 className="text-4xl font-extrabold mb-8 text-foreground">Our Products</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <Link
              key={product.id}
              to={`/product/${product.id}`}
              className="border border-border rounded-lg overflow-hidden bg-card hover:shadow-lg transition-shadow"
            >
              <div className="aspect-square bg-muted">
                <img
                  src={product.images[0]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2 text-card-foreground">{product.name}</h3>
                <p className="text-muted-foreground font-semibold mb-4">{product.description}</p>
                <div className="flex justify-between items-center">
                  <p className="text-xl font-extrabold text-card-foreground">₹{product.price}</p>
                  {product.freeShipping && (
                    <span className="text-sm text-primary font-bold">✓ Free Shipping</span>
                  )}
                </div>
              </div>
            </Link>
          ))}
        </div>
      </main>
    </div>
  );
};

export default Products;
