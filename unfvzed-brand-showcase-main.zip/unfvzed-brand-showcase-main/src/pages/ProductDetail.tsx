import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Navigation from "@/components/Navigation";
import { products } from "@/data/products";
import { Button } from "@/components/ui/button";
import { useCart } from "@/contexts/CartContext";
import { useToast } from "@/hooks/use-toast";
import { Minus, Plus, Instagram } from "lucide-react";

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const product = products.find((p) => p.id === id);
  const [selectedSize, setSelectedSize] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const { addToCart } = useCart();
  const { toast } = useToast();

  const productImages = product ? product.images : [];

  if (!product) {
    return (
      <div className="min-h-screen">
        <Navigation />
        <main className="container mx-auto px-6 pt-24 pb-12">
          <p>Product not found</p>
        </main>
      </div>
    );
  }

  const handleAddToCart = () => {
    if (!selectedSize) {
      toast({
        title: "Please select a size",
        variant: "destructive",
      });
      return;
    }

    const sizeStock = product.sizes.find((s) => s.size === selectedSize);
    if (!sizeStock || sizeStock.stock === 0) {
      toast({
        title: "Out of stock",
        description: "This size is currently unavailable",
        variant: "destructive",
      });
      return;
    }

    if (quantity > sizeStock.stock) {
      toast({
        title: "Insufficient stock",
        description: `Only ${sizeStock.stock} units available`,
        variant: "destructive",
      });
      return;
    }

    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      size: selectedSize,
      quantity,
      image: productImages[0],
    });

    toast({
      title: "Added to cart",
      description: `${quantity} x ${product.name} (${selectedSize})`,
    });
  };

  const getTotalStock = () => {
    return product.sizes.reduce((total, size) => total + size.stock, 0);
  };

  return (
    <div className="min-h-screen">
      <Navigation />
      <main className="container mx-auto px-6 pt-24 pb-12">
        <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          <div className="space-y-4">
            <div 
              className="aspect-square bg-muted rounded-lg overflow-hidden cursor-pointer"
              onClick={() => setCurrentImageIndex((prev) => (prev + 1) % productImages.length)}
            >
              <img
                src={productImages[currentImageIndex]}
                alt={product.name}
                className="w-full h-full object-cover object-[center_75%]"
              />
            </div>
            <div className="flex gap-2">
              {productImages.map((img, idx) => (
                <div
                  key={idx}
                  className={`w-20 h-20 rounded-lg overflow-hidden cursor-pointer border-2 ${
                    currentImageIndex === idx ? "border-primary" : "border-transparent"
                  }`}
                  onClick={() => setCurrentImageIndex(idx)}
                >
                  <img src={img} alt={`${product.name} ${idx + 1}`} className="w-full h-full object-cover" />
                </div>
              ))}
            </div>
          </div>
          <div className="space-y-6">
            <div>
              <h1 className="text-4xl font-extrabold mb-2 text-foreground">{product.name}</h1>
              <p className="text-muted-foreground text-lg font-semibold">{product.description}</p>
            </div>
            <div className="text-3xl font-extrabold text-foreground">₹{product.price}</div>
            {product.freeShipping && (
              <div className="text-primary font-bold text-lg">✓ Free Shipping</div>
            )}
            <div className="space-y-4">
              <div>
                <h3 className="font-bold mb-2 text-foreground text-lg">Select Size</h3>
                <div className="flex gap-2">
                  {product.sizes.map((sizeOption) => (
                    <Button
                      key={sizeOption.size}
                      variant={selectedSize === sizeOption.size ? "default" : "outline"}
                      onClick={() => setSelectedSize(sizeOption.size)}
                      disabled={sizeOption.stock === 0}
                      className="relative"
                    >
                      {sizeOption.size}
                      {sizeOption.stock === 0 && (
                        <span className="absolute inset-0 flex items-center justify-center bg-destructive/20 rounded">
                          <span className="text-xs font-bold text-white">Sold Out</span>
                        </span>
                      )}
                    </Button>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="font-bold mb-2 text-foreground text-lg">Quantity</h3>
                <div className="flex items-center gap-4">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <span className="text-2xl font-extrabold w-12 text-center text-foreground">{quantity}</span>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setQuantity(quantity + 1)}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
            <Button size="lg" className="w-full" onClick={handleAddToCart}>
              Add to Cart
            </Button>
            <div className="pt-4 border-t border-border">
              <a
                href="https://instagram.com/unfvzed.in"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-foreground hover:text-primary transition-colors justify-center"
              >
                <Instagram className="w-5 h-5" />
                <span className="text-sm font-semibold">Check out our Instagram @unfvzed.in to view more pictures</span>
              </a>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ProductDetail;
