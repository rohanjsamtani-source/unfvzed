import Navigation from "@/components/Navigation";
import { useCart } from "@/contexts/CartContext";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";

const Payment = () => {
  const { cart, getTotalPrice } = useCart();
  const navigate = useNavigate();

  useEffect(() => {
    if (cart.length === 0) {
      navigate("/cart");
    }
  }, [cart, navigate]);

  return (
    <div className="min-h-screen">
      <Navigation />
      <main className="container mx-auto px-6 pt-24 pb-12">
        <h1 className="text-4xl font-bold mb-8">Payment</h1>
        <div className="max-w-2xl mx-auto">
          <div className="bg-card border border-border rounded-lg p-8">
            <div className="text-center space-y-6">
              <div className="bg-muted p-8 rounded-lg">
                <h2 className="text-3xl font-bold mb-6">Razorpay Account Coming Soon</h2>
                <p className="text-lg text-muted-foreground mb-4">
                  We are currently setting up our Razorpay payment gateway to accept payments securely.
                </p>
                <p className="text-lg text-muted-foreground">
                  This will take approximately 4 days to complete.
                </p>
              </div>
              <div className="border-t border-border pt-6">
                <p className="text-xl font-bold mb-2">Your Order Total</p>
                <p className="text-3xl font-bold text-primary">₹{getTotalPrice()}</p>
              </div>
              <p className="text-sm text-muted-foreground font-semibold">
                Best regards,<br/>Team FVZ
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Payment;
